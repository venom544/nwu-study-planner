package za.ac.nwu.studyplanner.planner;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PlannerService {

    private final SubjectRepository subjects;
    private final StudySessionRepository sessions;

    public PlannerService(SubjectRepository subjects, StudySessionRepository sessions) {
        this.subjects = subjects;
        this.sessions = sessions;
    }

    public List<SubjectEntity> listSubjects(String ownerUsername) {
        return subjects.findAllByOwnerUsernameOrderByExamDateAscNameAsc(ownerUsername);
    }

    @Transactional
    public SubjectEntity upsertSubject(String ownerUsername, String name, LocalDate examDate, double totalHours, Difficulty difficulty) {
        SubjectEntity subject = subjects.findByOwnerUsernameAndNameIgnoreCase(ownerUsername, name)
                .orElseGet(() -> new SubjectEntity(ownerUsername, name, examDate, totalHours, difficulty));

        subject.setName(name);
        subject.setExamDate(examDate);
        subject.setTotalStudyHours(totalHours);
        subject.setDifficulty(difficulty);

        return subjects.save(subject);
    }

    public List<StudySessionEntity> listSessions(String ownerUsername) {
        return sessions.findAllByOwnerUsernameOrderBySessionDateAscStartTimeAscSubjectNameAsc(ownerUsername);
    }

    @Transactional
    public DeleteResult deleteAllData(String ownerUsername) {
        List<StudySessionEntity> sess = sessions.findAllByOwnerUsernameOrderBySessionDateAscStartTimeAscSubjectNameAsc(ownerUsername);
        List<SubjectEntity> subj = subjects.findAllByOwnerUsernameOrderByExamDateAscNameAsc(ownerUsername);

        // Batch deletes are reliable across DB naming/strategy differences.
        sessions.deleteAllInBatch(sess);
        subjects.deleteAllInBatch(subj);

        return new DeleteResult(subj.size(), sess.size());
    }

    public record DeleteResult(int deletedSubjects, int deletedSessions) {}

    @Transactional
    public void regenerateSchedule(String ownerUsername, LocalTime defaultStartTime) {
        sessions.deleteAllForOwner(ownerUsername);

        LocalDate today = LocalDate.now();
        List<SubjectEntity> subjectsForUser = listSubjects(ownerUsername);

        for (SubjectEntity s : subjectsForUser) {
            long days = ChronoUnit.DAYS.between(today, s.getExamDate());
            if (days <= 0) {
                continue;
            }

            double weight = difficultyWeight(s.getDifficulty());
            double weightedTotal = s.getTotalStudyHours() * weight;
            double hoursPerDay = weightedTotal / days;

            for (int i = 0; i < days; i++) {
                LocalDate day = today.plusDays(i);
                sessions.save(new StudySessionEntity(ownerUsername, s.getName(), day, defaultStartTime, hoursPerDay));
            }
        }
    }

    @Transactional
    public StudySessionEntity setSessionCompleted(String ownerUsername, long sessionId, boolean completed) {
        StudySessionEntity session = sessions.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found"));

        if (!session.getOwnerUsername().equalsIgnoreCase(ownerUsername)) {
            throw new IllegalArgumentException("Not allowed");
        }

        session.setCompleted(completed);
        StudySessionEntity saved = sessions.save(session);
        recomputeCompletedHours(ownerUsername, session.getSubjectName());
        return saved;
    }

    @Transactional
    public void recomputeCompletedHours(String ownerUsername, String subjectName) {
        List<StudySessionEntity> all = listSessions(ownerUsername);
        double completedHours = all.stream()
                .filter(s -> s.getSubjectName().equalsIgnoreCase(subjectName))
                .filter(StudySessionEntity::isCompleted)
                .mapToDouble(StudySessionEntity::getDurationHours)
                .sum();

        subjects.findByOwnerUsernameAndNameIgnoreCase(ownerUsername, subjectName).ifPresent(subj -> {
            subj.setCompletedHours(completedHours);
            subjects.save(subj);
        });
    }

    private static double difficultyWeight(Difficulty difficulty) {
        if (difficulty == null) {
            return 1.0;
        }
        return switch (difficulty) {
            case HIGH -> 1.30;
            case NORMAL -> 1.00;
            case LOW -> 0.80;
        };
    }
}

