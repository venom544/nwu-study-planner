package za.ac.nwu.studyplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NwuStudyPlannerApplication {
    public static void main(String[] args) {
        SpringApplication.run(NwuStudyPlannerApplication.class, args);
    }
}

