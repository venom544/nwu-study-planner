package za.ac.nwu.studyplanner.api;

import jakarta.validation.Valid;
import java.security.Principal;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import za.ac.nwu.studyplanner.api.dto.PlannerDtos;
import za.ac.nwu.studyplanner.planner.PlannerService;
import za.ac.nwu.studyplanner.planner.StudySessionEntity;
import za.ac.nwu.studyplanner.planner.SubjectEntity;

@RestController
@RequestMapping("/api")
public class PlannerController {

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    private final PlannerService planner;

    public PlannerController(PlannerService planner) {
        this.planner = planner;
    }

    @GetMapping("/subjects")
    public List<PlannerDtos.SubjectResponse> listSubjects(Principal principal) {
        String user = requireUser(principal);
        return planner.listSubjects(user).stream().map(PlannerController::toSubjectResponse).toList();
    }

    @PostMapping("/subjects")
    public PlannerDtos.SubjectResponse upsertSubject(Principal principal, @Valid @RequestBody PlannerDtos.SubjectUpsertRequest req) {
        String user = requireUser(principal);
        SubjectEntity saved = planner.upsertSubject(user, req.name(), req.examDate(), req.totalStudyHours(), req.difficulty());
        return toSubjectResponse(saved);
    }

    @GetMapping("/sessions")
    public List<PlannerDtos.SessionResponse> listSessions(Principal principal) {
        String user = requireUser(principal);
        return planner.listSessions(user).stream().map(PlannerController::toSessionResponse).toList();
    }

    @PostMapping("/schedule/generate")
    public void generateSchedule(Principal principal, @Valid @RequestBody PlannerDtos.GenerateScheduleRequest req) {
        String user = requireUser(principal);
        LocalTime time = LocalTime.parse(req.defaultStartTime(), TIME_FMT);
        planner.regenerateSchedule(user, time);
        // completedHours automatically recomputed when sessions are marked completed
    }

    @PostMapping("/sessions/{id}/completed")
    public PlannerDtos.SessionResponse setCompleted(
            Principal principal,
            @PathVariable("id") long id,
            @Valid @RequestBody PlannerDtos.SetCompletedRequest req
    ) {
        String user = requireUser(principal);
        StudySessionEntity updated = planner.setSessionCompleted(user, id, req.completed());
        return toSessionResponse(updated);
    }

    @PostMapping("/reset")
    public Object resetAll(Principal principal) {
        String user = requireUser(principal);
        return planner.deleteAllData(user);
    }

    private static String requireUser(Principal principal) {
        if (principal == null || principal.getName() == null || principal.getName().isBlank()) {
            throw new IllegalArgumentException("Not authenticated");
        }
        return principal.getName();
    }

    private static PlannerDtos.SubjectResponse toSubjectResponse(SubjectEntity s) {
        return new PlannerDtos.SubjectResponse(
                s.getId(),
                s.getName(),
                s.getExamDate(),
                s.getTotalStudyHours(),
                s.getCompletedHours(),
                s.getDifficulty()
        );
    }

    private static PlannerDtos.SessionResponse toSessionResponse(StudySessionEntity s) {
        return new PlannerDtos.SessionResponse(
                s.getId(),
                s.getSubjectName(),
                s.getSessionDate(),
                s.getStartTime().format(TIME_FMT),
                s.getDurationHours(),
                s.isCompleted()
        );
    }
}

