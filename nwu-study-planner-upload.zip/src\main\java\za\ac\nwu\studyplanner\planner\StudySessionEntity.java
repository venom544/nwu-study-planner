package za.ac.nwu.studyplanner.planner;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(
        name = "study_session",
        indexes = {
                @Index(name = "idx_session_owner_username", columnList = "ownerUsername"),
                @Index(name = "idx_session_owner_date", columnList = "ownerUsername,sessionDate")
        }
)
public class StudySessionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String ownerUsername;

    @Column(nullable = false, length = 120)
    private String subjectName;

    @Column(nullable = false)
    private LocalDate sessionDate;

    @Column(nullable = false)
    private LocalTime startTime;

    @Column(nullable = false)
    private double durationHours;

    @Column(nullable = false)
    private boolean completed;

    protected StudySessionEntity() {
    }

    public StudySessionEntity(
            String ownerUsername,
            String subjectName,
            LocalDate sessionDate,
            LocalTime startTime,
            double durationHours
    ) {
        this.ownerUsername = ownerUsername;
        this.subjectName = subjectName;
        this.sessionDate = sessionDate;
        this.startTime = startTime;
        this.durationHours = durationHours;
        this.completed = false;
    }

    public Long getId() {
        return id;
    }

    public String getOwnerUsername() {
        return ownerUsername;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public LocalDate getSessionDate() {
        return sessionDate;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public double getDurationHours() {
        return durationHours;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
}

