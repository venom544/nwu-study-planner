@echo off
setlocal

REM NWU Study Planner - one-click run script (Windows)
REM Requirements: Java 21+ installed and available on PATH.

cd /d "%~dp0"

echo Starting NWU Study Planner...
echo If this is the first run, it will download dependencies (wait).
echo.

call mvnw.cmd -q -DskipTests spring-boot:run

endlocal

