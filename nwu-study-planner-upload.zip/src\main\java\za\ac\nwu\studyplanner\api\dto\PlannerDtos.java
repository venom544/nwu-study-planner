package za.ac.nwu.studyplanner.api.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import za.ac.nwu.studyplanner.planner.Difficulty;

public class PlannerDtos {

    public record SubjectUpsertRequest(
            @NotBlank @Size(min = 2, max = 120) String name,
            @NotNull LocalDate examDate,
            @Min(1) double totalStudyHours,
            @NotNull Difficulty difficulty
    ) {}

    public record SubjectResponse(
            long id,
            String name,
            LocalDate examDate,
            double totalStudyHours,
            double completedHours,
            Difficulty difficulty
    ) {}

    public record SessionResponse(
            long id,
            String subjectName,
            LocalDate sessionDate,
            String startTime,
            double durationHours,
            boolean completed
    ) {}

    public record GenerateScheduleRequest(
            @Pattern(regexp = "^\\d{2}:\\d{2}$", message = "Time must be HH:mm") String defaultStartTime
    ) {}

    public record SetCompletedRequest(
            boolean completed
    ) {}
}

