## NWU Study Planner — User Manual (Web App)

### 1) Start the application

1. Double‑click `run-webapp.cmd`
2. Wait until it says the server started (first run takes longer)
3. Open your browser:
   - `http://localhost:8080`

### 2) Create an account (Sign Up)

1. Click **Sign Up**
2. Enter a username and password
3. Click **Create account**
4. You’ll be switched to **Sign In** (this is normal)

### 3) Log in (Sign In)

1. Enter your username and password
2. Click **Sign In**
3. The dashboard opens

Tip: Use the **👁 (eye)** button to show/hide your password.

### 4) Add subjects (modules)

On the **Dashboard**:

1. Enter **Subject name**
2. Choose **Exam date**
3. Enter **Total study hours**
4. Select **Difficulty** (LOW / NORMAL / HIGH)
5. Click **Save Subject**

Your subject will appear as a chip. Click a chip to load it for editing.

### 5) Generate your study schedule

1. Set the **Default start time**
2. Click **Generate schedule**

The system will create daily sessions from today until each exam date.

### 6) Mark sessions as completed

1. Open **Schedule** from the sidebar
2. Click **Mark done** on a session

Completed sessions update the progress bars and charts automatically.

### 7) Calendar view

1. Open **Calendar**
2. Navigate with ◀ / Today / ▶
3. Click any day to see the planned sessions

### 8) Charts and progress

On **Dashboard** you can see:

- **Progress Chart**: completion % per subject
- **Workload Chart**: planned hours/day for next 7 days

On **Progress** panel you can see:

- Progress bars per subject

### 9) Clear data / Logout

- **Clear all data**: sidebar → clears your subjects and sessions (useful for demos)
- **Logout**: sidebar → asks for confirmation → logs out

