package za.ac.nwu.studyplanner.planner;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface StudySessionRepository extends JpaRepository<StudySessionEntity, Long> {
    List<StudySessionEntity> findAllByOwnerUsernameOrderBySessionDateAscStartTimeAscSubjectNameAsc(String ownerUsername);
    List<StudySessionEntity> findAllByOwnerUsernameAndSessionDate(String ownerUsername, LocalDate sessionDate);

    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query(value = "delete from study_session where lower(owner_username) = lower(:ownerUsername)", nativeQuery = true)
    int deleteAllForOwner(@Param("ownerUsername") String ownerUsername);
}

