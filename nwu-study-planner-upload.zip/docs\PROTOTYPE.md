## NWU Study Planner — Prototype vs Final System

### What is the prototype?

The **prototype** is an early demonstration version of the Study Planner UI. It was created to quickly show:

- how the interface could look,
- what screens/features the system would have,
- the basic user flow (add subjects → generate schedule → track progress).

It runs as a **standalone HTML page** in the browser.

### Where to find the prototype

- Prototype file: `web\index.html`

### How to run the prototype

1. Open File Explorer and go to the project folder.
2. Open `web\index.html` in Chrome/Edge (double-click).

No server is required.

### Prototype limitations (important for marking)

The prototype is for UI demonstration. It is not a full system because:

- It does **not** use a database server-side.
- Login is **not** real authentication (it is browser-side demo logic).
- Data is not shared between machines/users the same way a real system would be.

### What is the final system?

The **final system** is the real implementation with:

- **Spring Boot backend**
- **Database storage (H2 file database)**
- **Real authentication** using **Spring Security sessions** and **BCrypt password hashing**
- A modern web UI served from the backend

### Where to find the final system

- Backend (Spring Boot): `src\main\java\za\ac\nwu\studyplanner\`
- Web UI served by Spring Boot: `src\main\resources\static\index.html`

### How to run the final system (recommended for presentation)

1. Ensure **Java 21+** is installed.
2. Run `run-webapp.cmd`
3. Open in a browser:
   - `http://localhost:8080`

### Why both exist

- **Prototype**: fast, early proof-of-concept and UI design.
- **Final system**: complete working solution with real data persistence and authentication.

