package za.ac.nwu.studyplanner.api;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import java.security.Principal;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import za.ac.nwu.studyplanner.api.dto.AuthDtos;
import za.ac.nwu.studyplanner.user.AppUser;
import za.ac.nwu.studyplanner.user.AppUserRepository;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final SecurityContextRepository securityContextRepository = new HttpSessionSecurityContextRepository();

    public AuthController(AppUserRepository users, PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public void register(@Valid @RequestBody AuthDtos.RegisterRequest req) {
        String username = req.username().trim().toLowerCase();
        if (users.existsByUsernameIgnoreCase(username)) {
            throw new IllegalArgumentException("Username already exists");
        }
        String hash = passwordEncoder.encode(req.password());
        users.save(new AppUser(username, hash));
    }

    @PostMapping("/login")
    public AuthDtos.MeResponse login(
            @Valid @RequestBody AuthDtos.LoginRequest req,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        UsernamePasswordAuthenticationToken token =
                new UsernamePasswordAuthenticationToken(req.username(), req.password());

        Authentication auth = authenticationManager.authenticate(token);
        SecurityContextImpl context = new SecurityContextImpl();
        context.setAuthentication(auth);
        SecurityContextHolder.setContext(context);

        // Persist authentication into the HTTP session so the browser keeps it via JSESSIONID cookie.
        securityContextRepository.saveContext(context, request, response);

        return new AuthDtos.MeResponse(true, auth.getName());
    }

    @GetMapping("/me")
    public AuthDtos.MeResponse me(Principal principal) {
        if (principal == null) {
            return new AuthDtos.MeResponse(false, null);
        }
        return new AuthDtos.MeResponse(true, principal.getName());
    }

    @PostMapping("/logout")
    public void logout() {
        // Handled by Spring Security logout filter at same URL
    }
}

