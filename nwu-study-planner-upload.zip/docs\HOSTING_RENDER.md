## Hosting NWU Study Planner (Free) — Render

This guide deploys the app publicly so anyone can access it.

### 1) Put the project on GitHub

Render deploys from a Git repository.

1. Create a GitHub account (if you don’t have one).
2. Create a new repository (example name: `nwu-study-planner`).
3. Upload/push this folder to that repository.

### 2) Create the Render services (1 click with `render.yaml`)

1. Go to Render dashboard
2. Click **New +** → **Blueprint**
3. Select your GitHub repo
4. Render will detect `render.yaml` and propose:
   - a **Web Service** (`nwu-study-planner`)
   - a **PostgreSQL database** (`nwu-study-planner-db`)
5. Click **Apply**

### 3) Wait for build + deploy

On first deploy, Render will:
- build the Docker image using `Dockerfile`
- create the database
- start the web service

When it’s done, you’ll get a public URL like:
- `https://nwu-study-planner.onrender.com`

### 4) Test the hosted app

1. Open the URL
2. Sign up
3. Add subject → generate schedule → confirm calendar and charts work

### Notes about the free plan

- The free web service may **sleep** when not used, so the first visit can be slow.
- Data is stored in the hosted database (PostgreSQL), so accounts and planner data remain saved.

