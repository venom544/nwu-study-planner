package za.ac.nwu.studyplanner.planner;

public enum Difficulty {
    LOW,
    NORMAL,
    HIGH
}

