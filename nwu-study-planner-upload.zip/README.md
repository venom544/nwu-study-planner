## NWU Study Planner

This project contains:

- **Console app (Java)**: `src\planner\StudyPlannerApp.java`
- **Real web app (Spring Boot + Database + Authentication)**: run locally and open in your browser

This is an **NWU Study Planner** console application written in Java. It helps students plan and track their study time for multiple subjects and exams in a neat, menu‑driven interface.

### Features (for your marks)

- Enter subjects
- Enter exam dates
- Calculate days remaining for each exam
- Allocate total study hours per subject
- Generate a day‑by‑day study schedule
- Track completed study sessions
- Display progress report
- Set study reminders (console notifications while the app is running)

### Run the web app (recommended for presentation)

1. Ensure **Java 21+** is installed.
2. Double‑click `run-webapp.cmd` (or run it from terminal).
3. Open the app in your browser:
   - `http://localhost:8080`

Notes:
- This uses **Maven Wrapper** (`mvnw.cmd`) so it works on lab PCs without installing Maven.
- Database is stored in `.\data\nwu-study-planner` so your users remain saved.

### Run the console app (optional)

1. Make sure you have **Java 8+** installed and `javac`/`java` available in your PATH.
2. From this folder, compile the source:

```bash
javac -d out src\\planner\\StudyPlannerApp.java
```

3. Run the program:

```bash
java -cp out planner.StudyPlannerApp
```

Follow the on‑screen menu to add subjects, create a schedule, mark sessions as complete, and view your progress.

### Documentation

See:

- `docs\DOCUMENTATION.md` (full project documentation)
- `docs\USER_MANUAL.md` (step-by-step user guide)
- `docs\API_REFERENCE.md` (backend endpoints)
- `docs\PROTOTYPE.md` (prototype vs final system)
- `docs\HOSTING_RENDER.md` (free hosting guide)

