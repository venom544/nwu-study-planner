package za.ac.nwu.studyplanner.planner;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SubjectRepository extends JpaRepository<SubjectEntity, Long> {
    List<SubjectEntity> findAllByOwnerUsernameOrderByExamDateAscNameAsc(String ownerUsername);
    Optional<SubjectEntity> findByOwnerUsernameAndNameIgnoreCase(String ownerUsername, String name);
    boolean existsByOwnerUsernameAndNameIgnoreCase(String ownerUsername, String name);

    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query(value = "delete from subject where lower(owner_username) = lower(:ownerUsername)", nativeQuery = true)
    int deleteAllForOwner(@Param("ownerUsername") String ownerUsername);
}

