## NWU Study Planner — Documentation

### 1) Project overview

**NWU Study Planner** is a Java-based system that helps students plan, balance, and track their study time across multiple modules and exam dates. It provides:

- A **real web application** (Spring Boot + Database + Authentication) for presentation and daily use
- A **Java console application** version (menu-driven) as an additional deliverable

### 2) Problem statement

Students often struggle to manage study time effectively when preparing for multiple modules and exams. Without a structured plan, learners may over-focus on certain modules while neglecting others, causing poor time management and increased stress near exam periods.

### 3) Solution summary

The system allows a student to:

- Capture subjects/modules and exam dates
- Allocate total study hours per subject
- Automatically generate a study plan/schedule from “today” until the exam date
- Mark sessions as completed to track progress
- View progress dashboards and charts
- Use reminders (while the web page is open)

### 4) Functional requirements (features)

#### Web app (Spring Boot)

- **Authentication**
  - Sign up (create account)
  - Sign in (login)
  - Logout (with confirmation)
- **Subjects**
  - Add/update subject name
  - Set exam date
  - Set total study hours
  - Set difficulty (LOW / NORMAL / HIGH)
- **Schedule**
  - Generate schedule using exam dates + difficulty weighting
  - View schedule as a table
  - Calendar month view with “selected day” session list
  - Mark sessions completed
- **Progress**
  - Progress bars per subject
  - Charts:
    - completion % per subject
    - planned workload (hours/day over next 7 days)
- **Data management**
  - “Clear all data” for the logged-in user

#### Console app (Java)

- Enter subjects
- Enter exam dates
- Calculate days remaining
- Allocate study hours
- Generate study schedule
- Track completed sessions
- Display progress report
- Set reminders (console notifications while running)

### 5) Non-functional requirements

- **Usability**: modern, dashboard-style web interface with sidebar navigation
- **Security**:
  - Passwords stored securely with **BCrypt hashing**
  - Session-based authentication via **Spring Security**
- **Portability**:
  - Uses **Maven Wrapper** so it can run on lab PCs without installing Maven
  - Only requires **Java 21+**
- **Persistence**:
  - H2 **file-based** database stores users + study data between restarts

### 6) Technology stack

- **Language**: Java 21
- **Backend**: Spring Boot 3 (Web, Security, Validation, JPA)
- **Database**: H2 (file-based)
- **Frontend**: HTML/CSS/JavaScript (served from Spring Boot)
- **Charts**: Chart.js (loaded via CDN)

### 7) High-level architecture

- **Frontend (Browser)**
  - Single-page UI served at `/`
  - Makes HTTP requests to backend endpoints under `/api/*`
- **Backend (Spring Boot)**
  - REST controllers handle authentication + planner operations
  - Services implement business logic (schedule generation, progress updates)
  - JPA/Hibernate persists data to H2 database
- **Database (H2 file)**
  - Stores users, subjects, and study sessions

### 8) Database design (conceptual)

#### Entities

- **User**
  - `id`
  - `username` (unique)
  - `passwordHash` (BCrypt)
- **Subject**
  - `id`
  - `ownerUsername` (username that owns this subject)
  - `name`
  - `examDate`
  - `totalStudyHours`
  - `completedHours`
  - `difficulty`
- **StudySession**
  - `id`
  - `ownerUsername`
  - `subjectName`
  - `sessionDate`
  - `startTime`
  - `durationHours`
  - `completed`

### 9) Scheduling logic (web)

- Schedule is generated **from today** until each subject’s exam date.
- A daily session is created for each day before the exam.
- **Difficulty weighting** adjusts the workload:
  - HIGH = 1.30× hours
  - NORMAL = 1.00× hours
  - LOW = 0.80× hours

### 10) API endpoints (backend)

#### Authentication (`/api/auth`)

- `POST /api/auth/register`
  - Body: `{ "username": "...", "password": "..." }`
- `POST /api/auth/login`
  - Body: `{ "username": "...", "password": "..." }`
  - Creates a session (cookie-based)
- `GET /api/auth/me`
  - Returns authenticated status + username
- `POST /api/auth/logout`

#### Planner (`/api`)

- `GET /api/subjects`
- `POST /api/subjects`
  - Body: `{ "name": "...", "examDate": "YYYY-MM-DD", "totalStudyHours": 12, "difficulty": "NORMAL" }`
- `GET /api/sessions`
- `POST /api/schedule/generate`
  - Body: `{ "defaultStartTime": "18:00" }`
- `POST /api/sessions/{id}/completed`
  - Body: `{ "completed": true }`
- `POST /api/reset`
  - Clears all subjects and sessions for the current user

### 11) How to run (portable / lab-friendly)

#### Web app (recommended for presentation)

1. Install **Java 21+**.
2. Copy the project folder to the lab PC (e.g., via USB).
3. Double-click:
   - `run-webapp.cmd`
4. Open:
   - `http://localhost:8080`

The first run may take longer while dependencies download.

#### Console app

From project root:

```bash
javac -d out src\planner\StudyPlannerApp.java
java -cp out planner.StudyPlannerApp
```

### 12) User guide (web)

1. **Sign up** → create an account.
2. **Sign in** → access your planner.
3. **Dashboard → Save Subject**: add name, exam date, hours, difficulty.
4. **Dashboard → Generate schedule**: creates sessions.
5. **Schedule**: mark sessions completed.
6. **Progress/Charts**: view completion and workload.
7. **Calendar**: month view for sessions and daily details.
8. **Sidebar → Clear all data**: resets your plan (use for demos).

### 13) Limitations / future improvements

- Email/SMS reminders (currently in-app reminders while page is open)
- Editing/deleting individual subjects and sessions (instead of “clear all”)
- Export schedule to PDF/Excel
- Multi-device hosted deployment (e.g., AWS/Render) instead of local-only

### 14) Hosting / deployment (public access)

To make the app accessible by anyone, deploy it with a hosted database (PostgreSQL).

**Production profile**: `prod`

Required environment variables on the hosting platform:

- `SPRING_PROFILES_ACTIVE=prod`
- `SPRING_DATASOURCE_URL=jdbc:postgresql://<host>:5432/<db>`
- `SPRING_DATASOURCE_USERNAME=<db_user>`
- `SPRING_DATASOURCE_PASSWORD=<db_password>`
- `PORT` is provided automatically on many hosts (the app uses `server.port=${PORT:8080}`)


