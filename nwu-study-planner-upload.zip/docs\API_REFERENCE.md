## NWU Study Planner — API Reference

Base URL (local): `http://localhost:8080`

All endpoints return JSON unless otherwise noted.

### Authentication

#### `POST /api/auth/register`

Creates a new user account.

**Body**

```json
{ "username": "student1", "password": "pass1234" }
```

**Responses**
- `201 Created`: success
- `400 Bad Request`: invalid input or username already exists

#### `POST /api/auth/login`

Logs in using session authentication.

**Body**

```json
{ "username": "student1", "password": "pass1234" }
```

**Response**

```json
{ "authenticated": true, "username": "student1" }
```

#### `GET /api/auth/me`

Returns whether the current session is authenticated.

**Response**

```json
{ "authenticated": false, "username": null }
```

#### `POST /api/auth/logout`

Logs out the current session.

### Subjects

#### `GET /api/subjects`

Lists the logged-in user’s subjects.

**Response**

```json
[
  {
    "id": 1,
    "name": "Mathematics",
    "examDate": "2026-04-01",
    "totalStudyHours": 12.0,
    "completedHours": 0.0,
    "difficulty": "NORMAL"
  }
]
```

#### `POST /api/subjects`

Creates or updates a subject (upsert by subject name).

**Body**

```json
{
  "name": "Mathematics",
  "examDate": "2026-04-01",
  "totalStudyHours": 12,
  "difficulty": "HIGH"
}
```

### Schedule & sessions

#### `POST /api/schedule/generate`

Deletes old sessions and regenerates daily sessions until exam.

**Body**

```json
{ "defaultStartTime": "18:00" }
```

#### `GET /api/sessions`

Returns all scheduled sessions for the logged-in user.

**Response**

```json
[
  {
    "id": 10,
    "subjectName": "Mathematics",
    "sessionDate": "2026-03-17",
    "startTime": "18:00",
    "durationHours": 0.8,
    "completed": false
  }
]
```

#### `POST /api/sessions/{id}/completed`

Marks a session completed or pending.

**Body**

```json
{ "completed": true }
```

### Reset

#### `POST /api/reset`

Clears all subjects and sessions for the current user.

